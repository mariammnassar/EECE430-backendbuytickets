from datetime import datetime

def addEvent(conn, cursor, title, description, schedule_date, schedule_time, loc):
    # check in app.py if dob format is correct: set Boolean variable and check for empties

    # new event, insert into database
    try:
        query1 = "insert into schedule "
        query2 = f"values('{title}', '{description}', '{schedule_date}', '{schedule_time}', '{loc});"
        cursor.execute(query1 + query2)
        conn.commit()
        print('Event successfully added!')
        return True
    except Exception as e:
        print(e)
        print('\nData already inserted into schedule relation.')

def titleFormat(title):
    if len(title) > 50:
        return False

def descriptionFormat(description):
    if len(description) > 255:
        return False

def schedule_dateFormat(schedule_date):
#     'DD/MM/YYYY'
    DD = schedule_date[0:2]
    MM = schedule_date[3:5]
    YYYY = schedule_date[6:10]
    test = YYYY + '-' + MM + '-' + DD
#
    try:
        if test != datetime.strptime(test, "%Y-%m-%d").strftime('%Y-%m-%d'):
            #raise ValueError
            return False
        return True
    except ValueError as e:
        print(e)
        return False

def schedule_timeFormat(schedule_time):
#     'HH1:MM1-HH2:MM2'
    HH1 = schedule_time[0:2]
    MM1 = schedule_time[3:5]
    HH2 = schedule_time[6:8]
    MM2 = schedule_time[9:11]
    test = HH1 + ':' + MM1 + '-' + HH2 + ':' + MM2
#
    try:
        if test != datetime.strptime(test, "%H:%M-%H:%M").strftime('%H:%M-%H:%M'):
            #raise ValueError
            return False
        return True
    except ValueError as e:
        print(e)
        return False

def locFormat(loc):
    if len(loc) > 30:
        return False

def updateDate(conn, cursor, title, newDate):
    try:
        query = 'update schedule set schedule_date = \'' + newDate + '\'' + 'where title = \'' + title + '\';'
        cursor.execute(query)
        conn.commit()
        print('Date updated!')
        return True
    except Exception as e:
        print(e)
        return False

def updateTime(conn, cursor, title, newTime):
    try:
        query = 'update schedule set schedule_time = \'' + newTime + '\'' + 'where title = \'' + title + '\';'
        cursor.execute(query)
        conn.commit()
        print('Time updated!')
        return True
    except Exception as e:
        print(e)
        return False

def updateLoc(conn, cursor, loc, newLoc):
    try:
        query = 'update schedule set loc = \'' + newLoc + '\'' + 'where loc = \'' + loc + '\';'
        cursor.execute(query)
        conn.commit()
        print('Location updated!')
        return True
    except Exception as e:
        print(e)
        return False

def deleteEvent(conn, cursor, title):
    try:
        query = 'delete from schedule where title = \'' + title + '\';'
        cursor.execute(query)
        conn.commit()
        return True
    except Exception as e:
        print(e)
        return False

def belongs(conn, cursor, instance, relation):
    query = 'select * from ' + relation
    cursor.execute(query)
    result = cursor.fetchall()
    for row in result:
        if instance in row:
            return True
    return False

