from datetime import datetime

def addticket(conn, cursor, ticket_title, ticket_class, ticket_date, ticket_time, ticket_price, ticket_location):
    # check in app.py if dob format is correct: set Boolean variable and check for empties

    # new event, insert into database
    try:
        query1 = "insert into tickets "
        query2 = f"values('{ticket_title}', '{ticket_class}', '{ticket_date}', '{ticket_time}','{ticket_price}','{ticket_location}');"
        cursor.execute(query1 + query2)
        conn.commit()
        print('Ticket successfully added!')
        return True
    except Exception as e:
        print(e)
        print('\nData already inserted into schedule relation.')

def ticket_titleFormat(ticket_title):
    if len(ticket_title) > 50:
        return False


def ticket_classFormat(ticket_class):
    if len(ticket_class) > 25:
        return False


def ticket_locationFormat(ticket_location):
    if len(ticket_location) > 25:
        return False

def ticket_dateFormat(ticket_date):
 #     'DD/MM/YYYY'
    DD = ticket_date[0:2]
    MM = ticket_date[3:5]
    YYYY = ticket_date[6:10]
    test = YYYY + '-' + MM + '-' + DD
#
    try:
        if test != datetime.strptime(test, "%Y-%m-%d").strftime('%Y-%m-%d'):
            #raise ValueError
            return False
        return True
    except ValueError as e:
        print(e)
        return False

def ticket_timeFormat(ticket_time):
#     'DD/MM/YYYY'
    HH1 = ticket_time[0:2]
    MM1 = ticket_time[3:5]
    HH2 = ticket_time[6:8]
    MM2 = ticket_time[9:11]
    test = HH1 + ':' + MM1 + '-' + HH2 + ':' + MM2
#
    try:
        if test != datetime.strptime(test, "%H:%M-%H:%M").strftime('%H:%M-%H:%M'):
            #raise ValueError
            return False
        return True
    except ValueError as e:
        print(e)
        return False

def ticket_priceFormat(ticket_price):
    if type(ticket_price) != float:
        return False


def ticket_quantityFormat(ticket_quantity):
    if type(ticket_quantity) != int:
        return False


def update_ticketDate(conn, cursor, ticket_title, newTicketDate):
    try:
        query = 'update tickets set ticket_date = \'' + newTicketDate + '\'' + 'where ticket_title = \'' + ticket_title + '\';'
        cursor.execute(query)
        conn.commit()
        print('Date updated!')
        return True
    except Exception as e:
        print(e)
        return False

def updatePrice(conn, cursor, ticket_title, newPrice):
    try:
        query = 'update tickets set ticket_price = \'' + newPrice + '\'' + 'where ticket_title = \'' + ticket_title + '\';'
        cursor.execute(query)
        conn.commit()
        print('Price updated!')
        return True
    except Exception as e:
        print(e)
        return False

def updateLocation(conn, cursor, ticket_title, newLocation):
    try:
        query = 'update tickets set ticket_location = \'' + newLocation + '\'' + 'where ticket_title = \'' + ticket_title + '\';'
        cursor.execute(query)
        conn.commit()
        print('Location updated!')
        return True
    except Exception as e:
        print(e)
        return False

def updateQuantity(conn, cursor, ticket_title, newQuantity):
    try:
        query = 'update tickets set ticket_quantity = \'' + newQuantity + '\'' + 'where ticket_title = \'' + ticket_title + '\';'
        cursor.execute(query)
        conn.commit()
        print('quantity updated!')
        return True
    except Exception as e:
        print(e)
        return False

def deleteTicket(conn, cursor, ticket_title):
    try:
        query = 'delete from tickets where ticket_title = \'' + ticket_title + '\';'
        cursor.execute(query)
        conn.commit()
        return True
    except Exception as e:
        print(e)
        return False


def belongs(conn, cursor, instance, relation):
    query = 'select * from ' + relation
    cursor.execute(query)
    result = cursor.fetchall()
    for row in result:
        if instance in row:
            return True
    return False